import React from 'react';
import { Link } from 'react-router-dom';

function SuccessPage() {
  return (
    <div className="success-page">
      <h1>Estimate Saved</h1>
      <p>Go back to the <Link to="/">previous page</Link>.</p>
    </div>
  );
}

export default SuccessPage;