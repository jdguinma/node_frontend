import React, { useState, useEffect } from 'react';

const Hardscape = ({ initialHardscapeItems }) => {
  const [hardscapeItems, setHardscapeItems] = useState(initialHardscapeItems || []);
  const [selectorValues, setSelectorValues] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  // New state to track titles with 'Add' selected and their corresponding values
  const [titlesWithAdd, setTitlesWithAdd] = useState({});

  useEffect(() => {
  const fetchData = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('http://ec2-3-92-147-193.compute-1.amazonaws.com:80/data');
      if (!response.ok) throw new Error('Failed to fetch data');
      const data = await response.json();
      setHardscapeItems(data.hardscapeItems || []);

      // Initialize titlesWithAdd and selectorValues from fetched data
      const fetchedTitlesWithAdd = {};
      const initialSelectorValues = {};
      data.hardscapeItems.forEach((item, itemIndex) => {
        item.selectors.forEach((selector, choiceIndex) => {
          const selectorKey = `${itemIndex}-${choiceIndex}`;
          initialSelectorValues[selectorKey] = selector; // Store the initial selector state
          if (selector === 'Add') {
            fetchedTitlesWithAdd[item.title] = item.values[choiceIndex];
          }
        });
      });
      setTitlesWithAdd(fetchedTitlesWithAdd);
      setSelectorValues(initialSelectorValues); // Initialize the selectorValues state
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  if (!initialHardscapeItems?.length) {
    fetchData();
  }
}, [initialHardscapeItems]);

  const handleSelectorChange = async (itemIndex, choiceIndex, newValue) => {
    const key = `${itemIndex}-${choiceIndex}`;
    const newSelectorValues = { ...selectorValues, [key]: newValue };
    setSelectorValues(newSelectorValues);

    // Check if the newValue is 'Add' and update the titlesWithAdd state
    const updatedTitlesWithAdd = { ...titlesWithAdd };
    if (newValue === 'Add') {
      updatedTitlesWithAdd[hardscapeItems[itemIndex].title] = hardscapeItems[itemIndex].values[choiceIndex];
    } else {
      delete updatedTitlesWithAdd[hardscapeItems[itemIndex].title];
    }
    setTitlesWithAdd(updatedTitlesWithAdd);

    try {
      const response = await fetch('http://ec2-3-92-147-193.compute-1.amazonaws.com:80/updateSelector', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          itemIndex,
          choiceIndex,
          selector: newValue,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to update selector');
      }

      // Optionally, refresh data or handle success
    } catch (error) {
      console.error('Error updating selector:', error.message);
      setError(error.message);
    }
  };

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

return (
    <div>
      <h2>Hardscape Section</h2>
      {hardscapeItems.map((item, index) => {
        const addValue = titlesWithAdd[item.title];
        return (
          <div key={index}>
            <h3>
              {item.title}
              {addValue ? ` - Hours Estimate Added (Value: ${addValue})` : ''}
            </h3>
            {item.choices.map((choice, choiceIndex) => {
              const selectorKey = `${index}-${choiceIndex}`;
              const isAddSelected = selectorValues[selectorKey] === 'Add';
              return (
                <div key={choiceIndex}>
                  <span style={{ fontWeight: isAddSelected ? 'bold' : 'normal' }}>
                    {choice} - {isAddSelected ? `Hours Estimate: ${item.values[choiceIndex]}` : item.values[choiceIndex]}
                  </span>
                  <select
                    value={selectorValues[selectorKey] || ""}
                    onChange={(e) => handleSelectorChange(index, choiceIndex, e.target.value)}
                  >
                    <option value="">Please select...</option>
                    <option value="Add">Add</option>
                  </select>
                </div>
              );
            })}
          </div>
        );
      })}
    </div>
  );
};

export default Hardscape;

