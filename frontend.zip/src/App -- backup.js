import React, { useState, useEffect } from 'react';

function App() {
  const [projectArea, setProjectArea] = useState('');
  const [deliverables, setDeliverables] = useState([]);
  const [totalBudgetedHours, setTotalBudgetedHours] = useState('');
  const [totalFee, setTotalFee] = useState('');

  function handleProjectAreaChange(e) {
    const newValue = e.target.value;
    setProjectArea(newValue); // Update local state

    // Prepare data to send to backend
    const data = {
      range: 'Instant Design Estimate Worksheet 3!B2',
      value: newValue,
    };

    // Send updated data to backend
    fetch('http://localhost:3001/updateCell', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    })
    .then(response => response.json())
    .then(data => {
      console.log('Success:', data);
      fetchUpdatedData(); // Fetch the updated data
    })
    .catch((error) => console.error('Error:', error));
  }

  function handleAddReduceHoursChange(deliverableIndex, newValue) {
    // Update the deliverables state
    const updatedDeliverables = deliverables.map((deliverable, index) => {
      if (index === deliverableIndex) {
        return { ...deliverable, addReduceHours: newValue };
      }
      return deliverable;
    });
    setDeliverables(updatedDeliverables);

    // Prepare data to send to backend
    const data = {
      range: `Instant Design Estimate Worksheet 3!H${deliverableIndex + 4}`, // Assuming H4 is the start
      value: newValue,
    };

    // Send updated data to backend
    fetch('http://localhost:3001/updateCell', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    })
    .then(response => response.json())
    .then(data => {
      console.log('Success:', data);
      fetchUpdatedData(); // Fetch the updated data
    })
    .catch((error) => console.error('Error:', error));
  }

  // fetching updated data
  const fetchUpdatedData = () => {
  fetch('http://localhost:3001/data')
    .then((response) => response.json())
    .then((data) => {
      // Update state with the new data
      setProjectArea(data.projectArea);
      setTotalBudgetedHours(data.totalBudgetedHours);
      setTotalFee(data.totalFee);

      // Update deliverables with the inclusion status
      const updatedDeliverables = data.deliverables.map(deliverable => ({
        ...deliverable,
        inclusion: deliverable.inclusion // Make sure this is 'Yes' or 'Don't Include'
      }));
      setDeliverables(updatedDeliverables);
    })
    .catch((error) => console.error('Error:', error));
  };

  function handleInclusionChange(deliverableIndex, newInclusionStatus) {
  const updatedDeliverables = deliverables.map((deliverable, index) => {
    if (index === deliverableIndex) {
      return { ...deliverable, inclusion: newInclusionStatus };
    }
    return deliverable;
  });
  setDeliverables(updatedDeliverables);
  
  // Prepare data to send to the backend
  const data = {
    range: `Instant Design Estimate Worksheet 3!D${deliverableIndex + 4}`, // Adjust if your range is different
    value: newInclusionStatus,
  };

  // Send updated data to the backend
  fetch('http://localhost:3001/updateCell', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  })
  .then(response => response.json())
  .then(data => {
    console.log('Success:', data);
    fetchUpdatedData(); // Fetch the updated data
  })
  .catch((error) => console.error('Error:', error));
  }


  useEffect(() => {
    fetchUpdatedData(); // Fetch data on component mount
  }, []);

  // Polling
  useEffect(() => {
    const interval = setInterval(() => {
      fetchUpdatedData(); // Fetch data periodically
    }, 5000); // Poll every 5 seconds, adjust as needed

    return () => clearInterval(interval); // Cleanup on unmount
  }, []);

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log({ projectArea, deliverables, totalBudgetedHours, totalFee });
  };

  return (
    <div className="App">
      <form onSubmit={handleSubmit}>
        {/* Project Area */}
        <div>
          <label>Project Area:</label>
          <input 
            type="text" 
            value={projectArea} 
            onChange={handleProjectAreaChange}
          />
        </div>
        {/* Deliverables */}
        {deliverables.map((deliverable, index) => (
          <div key={index}>
            <h3>{deliverable.title}</h3>
            
            {/* Dropdown for inclusion status */}
            <div>
              <label>Include: </label>
              <select
                value={deliverable.inclusion}
                onChange={(e) => handleInclusionChange(index, e.target.value)}
              >
                <option value="Yes">Yes</option>
                <option value="Don't Include">Don't Include</option>
              </select>
            </div>

            {/* Conditionally render the following fields only if inclusion is 'Yes' */}
            {deliverable.inclusion === 'Yes' && (
              <>
                <div>
                  <label>Hours:</label>
                  <span>{deliverable.hours}</span>
                </div>
                <div>
                  <label>Rate Per Hour:</label>
                  <span>{deliverable.rate}</span>
                </div>
                <div>
                  <label>Add/Reduce Hours:</label>
                  <input
                    type="text"
                    value={deliverable.addReduceHours}
                    onChange={(e) => handleAddReduceHoursChange(index, e.target.value)}
                  />
                </div>
                <div>
                  <label>Fee:</label>
                  <span>{deliverable.fee}</span>
                </div>
              </>
            )}
          </div>
        ))}

        <div> </div>
        {/* Total Budgeted Hours */}
        <div>
          <label>Total Budgeted Hours:</label>
          <span>{totalBudgetedHours}</span>
        </div>

        {/* Total Fee */}
        <div>
          <label>Total Fee:</label>
          <span>{totalFee}</span>
        </div>

        {/* Submit Button */}
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default App;
