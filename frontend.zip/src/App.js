import React, { useState, useEffect } from 'react';
import './App.css';
import Hardscape from './Hardscape';

function App() {
  const [projectArea, setProjectArea] = useState('');
  const [deliverables, setDeliverables] = useState([]);
  const [totalBudgetedHours, setTotalBudgetedHours] = useState('');
  const [totalFee, setTotalFee] = useState('');
  const [hardscapeItems, setHardscapeItems] = useState([]);

  // Handles changes to the project area input
  function handleProjectAreaChange(e) {
    const newValue = e.target.value;
    setProjectArea(newValue);
    updateCell('Instant Design Estimate Worksheet 3!B2', newValue);
  }

  // Handles changes to add/reduce hours for a specific deliverable
  function handleAddReduceHoursChange(deliverableIndex, newValue) {
    const updatedDeliverables = deliverables.map((deliverable, index) => {
      if (index === deliverableIndex) {
        return { ...deliverable, addReduceHours: newValue };
      }
      return deliverable;
    });
    setDeliverables(updatedDeliverables);
    updateCell(`Instant Design Estimate Worksheet 3!H${deliverableIndex + 4}`, newValue);
  }

  // Handles changes to the inclusion status of a deliverable
  function handleInclusionChange(deliverableIndex, newInclusionStatus) {
    const updatedDeliverables = deliverables.map((deliverable, index) => {
      if (index === deliverableIndex) {
        return { ...deliverable, inclusion: newInclusionStatus };
      }
      return deliverable;
    });
    setDeliverables(updatedDeliverables);
    updateCell(`Instant Design Estimate Worksheet 3!D${deliverableIndex + 4}`, newInclusionStatus);
  }

  // Fetches and updates data from the backend
  const fetchUpdatedData = () => {
//    fetch('http://localhost:3001/data')
    fetch('http://ec2-3-92-147-193.compute-1.amazonaws.com:80/data')
      .then((response) => response.json())
      .then((data) => {
        setProjectArea(data.projectArea);
        setTotalBudgetedHours(data.totalBudgetedHours);
        setTotalFee(data.totalFee);
        setDeliverables(data.deliverables);
        setHardscapeItems(data.hardscapeItems); // Assuming the data includes hardscapeItems
      })
      .catch((error) => console.error('Error:', error));
  };

  // Generic function to update cell values in the backend
  const updateCell = (range, value) => {
//    fetch('http://localhost:3001/updateCell', {
    fetch('http://ec2-3-92-147-193.compute-1.amazonaws.com:80/updateCell', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ range, value }),
    })
      .then(response => response.json())
      .then(data => console.log('Success:', data))
      .catch(error => console.error('Error:', error));
  };

  // Fetch data on component mount and set up polling
  useEffect(() => {
    fetchUpdatedData();
    const interval = setInterval(fetchUpdatedData, 5000); // Adjust as needed
    return () => clearInterval(interval);
  }, []);

  // Handle form submission
 /* const handleSubmit = (event) => {
    event.preventDefault();
    console.log({ projectArea, deliverables, totalBudgetedHours, totalFee });
    // Potentially here you would want to post this data back to a server or handle it accordingly
  };
*/
  const handleSubmit = (event) => {
    event.preventDefault();

    // Format the data
    const submissionData = {
      client: `Client ${Math.floor(Math.random() * 1000)}`, // Random client number
      projectArea,
      deliverables: deliverables.filter(d => d.inclusion === "Yes").map(d => ({
        title: d.title,
        hours: d.hours,
        rate: d.rate,
        fee: d.fee,
      })),
      hardscapeItems: hardscapeItems.filter(item => item.selectors.includes('Add')).map(item => ({
        title: item.title,
        value: item.values.join(', '), // Assuming you want to join all values
      })),
      totalBudgetedHours,
      totalFee,
    };

    // POST the data to the backend
//    fetch('http://localhost:3001/submitData', {
    fetch('http://ec2-3-92-147-193.compute-1.amazonaws.com:80/submitData', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(submissionData),
    })
      .then(response => response.json())
      .then(data => {
        console.log('Success:', data);
      })
      .catch(error => console.error('Error:', error));
  };

  return (
    <div className="App">
      <form onSubmit={handleSubmit}>
        {/* Project Area */}
        <div className="form-group">
          <label>Project Area:</label>
          <input
            type="text"
            className="form-control"
            value={projectArea}
            onChange={handleProjectAreaChange}
          />
        </div>
        {/* Deliverables */}
        {deliverables.map((deliverable, index) => (
          <div key={index} className="deliverable">
            <h3>{deliverable.title}</h3>

            {/* Dropdown for inclusion status */}
            <div className="form-group">
              <label className="italic-label">Include: </label>
              <select
                className="form-control"
                value={deliverable.inclusion}
                onChange={(e) => handleInclusionChange(index, e.target.value)}
              >
                <option value="Yes">Yes</option>
                <option value="Don't Include">Don't Include</option>
              </select>
            </div>

            {/* Conditionally render the following fields only if inclusion is 'Yes' */}

            {deliverable.inclusion === 'Yes' && (
              <>
                <div className="form-group">
                  <label>Hours:</label>
                  <span className="form-text">{deliverable.hours}</span>
                </div>
                <div className="form-group">
                  <label>Rate Per Hour:</label>
                  <span className="form-text">{deliverable.rate}</span>
                </div>
                <div className="form-group">
                  <label>Add/Reduce Hours:</label>
                  <input
                    type="text"
                    className="form-control add-reduce-hours"
                    value={deliverable.addReduceHours}
                    onChange={(e) => handleAddReduceHoursChange(index, e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label>Fee:</label>
                  <span className="form-text">{deliverable.fee}</span>
                </div>
              </>
            )}
          </div>
        ))}

        {/* Hardscape Section */}
        <Hardscape hardscapeItems={hardscapeItems} onUpdateHardscape={setHardscapeItems} />

        {/* Total Budgeted Hours */}
        <div className="form-group">
          <label>Total Budgeted Hours:</label>
          <span className="form-text">{totalBudgetedHours}</span>
        </div>

        {/* Total Fee */}
        <div className="form-group">
          <label>Total Fee:</label>
          <span className="form-text">{totalFee}</span>
        </div>

        {/* Submit Button */}
        <button type="submit" className="submit-button">Submit</button>
      </form>
    </div>
  );
}

export default App;